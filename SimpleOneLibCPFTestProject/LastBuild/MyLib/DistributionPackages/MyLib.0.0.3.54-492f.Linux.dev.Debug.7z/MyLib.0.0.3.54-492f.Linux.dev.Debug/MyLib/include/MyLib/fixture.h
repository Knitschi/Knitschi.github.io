#include <MyLib/mylib_tests_export.h>


namespace mylib
{
	class MYLIB_TESTS_EXPORT MyFixture
	{
	  public:
		void setUp();
	};
}