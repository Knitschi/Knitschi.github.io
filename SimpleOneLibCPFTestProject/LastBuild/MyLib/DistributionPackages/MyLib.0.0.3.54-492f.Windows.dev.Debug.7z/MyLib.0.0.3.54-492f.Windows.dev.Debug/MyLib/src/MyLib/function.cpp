#include <MyLib/function.h>
#include <iostream>

namespace mylib
{
	void function()
	{
		std::cout << "MyLib function()\n";
	}
}
