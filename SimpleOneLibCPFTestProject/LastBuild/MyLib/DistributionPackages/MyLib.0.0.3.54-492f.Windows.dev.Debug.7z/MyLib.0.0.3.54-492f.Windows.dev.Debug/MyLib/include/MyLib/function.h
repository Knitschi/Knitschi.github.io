#pragma once

#include <MyLib/mylib_export.h>

namespace mylib
{
	/**
	\short A function that prints the version of MyLib.
	*/
	MYLIB_EXPORT void function();
}
