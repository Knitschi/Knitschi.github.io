#include <MyLib/fixture.h>


int main(int, char**)
{
	mylib::MyFixture f;
	f.setUp();

	return 0;
}
