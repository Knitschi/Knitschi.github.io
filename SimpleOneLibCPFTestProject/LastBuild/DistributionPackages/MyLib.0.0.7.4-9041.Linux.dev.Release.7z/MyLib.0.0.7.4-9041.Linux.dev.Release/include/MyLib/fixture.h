#include <MyLib/mylib_fixtures_export.h>


namespace mylib
{
	class MYLIB_FIXTURES_EXPORT MyFixture
	{
	  public:
		void setUp();
	};
}