#pragma once

#include <FPackage/f_export.h>

namespace f
{
	F_EXPORT void function();
}
