#pragma once

#include <iostream>

namespace g
{
	inline void function()
	{
		std::cout << "GPackage function()"
				  << "\n";
	}
}
