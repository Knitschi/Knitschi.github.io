#pragma once

#include <BPackage/bpackage_export.h>

namespace b
{
	BPACKAGE_EXPORT void function();
}
