#pragma once

#include <BPackage/b_export.h>

namespace b
{
	B_EXPORT void function();
}
