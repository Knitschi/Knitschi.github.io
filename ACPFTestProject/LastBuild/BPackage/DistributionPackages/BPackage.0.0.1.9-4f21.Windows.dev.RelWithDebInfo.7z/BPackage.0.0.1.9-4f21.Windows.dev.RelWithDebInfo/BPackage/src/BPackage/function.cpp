#include <BPackage/function.h>
#include <iostream>

namespace b
{
	void function()
	{
		std::cout << "BPackage function()"
				  << "\n";
	}
}
