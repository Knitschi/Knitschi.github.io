#include <CPackage/Tests/function_fixture.h>

namespace c
{
	bool FunctionFixture::SetUp()
	{
		return true;
	}
}