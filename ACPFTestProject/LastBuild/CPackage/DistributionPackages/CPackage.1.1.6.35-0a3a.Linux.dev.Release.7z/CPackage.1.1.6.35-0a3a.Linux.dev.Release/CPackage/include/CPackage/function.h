#pragma once

#include <CPackage/c_export.h>

namespace c
{
	C_EXPORT void function();
}
