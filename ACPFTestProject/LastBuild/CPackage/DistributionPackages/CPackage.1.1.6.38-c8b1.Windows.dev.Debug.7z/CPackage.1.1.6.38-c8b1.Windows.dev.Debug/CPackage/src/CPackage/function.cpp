#include <CPackage/function.h>

namespace c
{
	void function() {}
}
