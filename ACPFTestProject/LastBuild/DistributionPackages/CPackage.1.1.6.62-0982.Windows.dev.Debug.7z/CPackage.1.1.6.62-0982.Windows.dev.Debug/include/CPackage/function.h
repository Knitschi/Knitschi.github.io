#pragma once

#include <CPackage/cpackage_export.h>

namespace c
{
	CPACKAGE_EXPORT void function();
}
