
#ifndef CPACKAGE_FIXTURES_EXPORT_H
#define CPACKAGE_FIXTURES_EXPORT_H

#ifdef CPACKAGE_FIXTURES_STATIC_DEFINE
#  define CPACKAGE_FIXTURES_EXPORT
#  define CPACKAGE_FIXTURES_NO_EXPORT
#else
#  ifndef CPACKAGE_FIXTURES_EXPORT
#    ifdef CPackage_fixtures_EXPORTS
        /* We are building this library */
#      define CPACKAGE_FIXTURES_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define CPACKAGE_FIXTURES_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef CPACKAGE_FIXTURES_NO_EXPORT
#    define CPACKAGE_FIXTURES_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef CPACKAGE_FIXTURES_DEPRECATED
#  define CPACKAGE_FIXTURES_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef CPACKAGE_FIXTURES_DEPRECATED_EXPORT
#  define CPACKAGE_FIXTURES_DEPRECATED_EXPORT CPACKAGE_FIXTURES_EXPORT CPACKAGE_FIXTURES_DEPRECATED
#endif

#ifndef CPACKAGE_FIXTURES_DEPRECATED_NO_EXPORT
#  define CPACKAGE_FIXTURES_DEPRECATED_NO_EXPORT CPACKAGE_FIXTURES_NO_EXPORT CPACKAGE_FIXTURES_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef CPACKAGE_FIXTURES_NO_DEPRECATED
#    define CPACKAGE_FIXTURES_NO_DEPRECATED
#  endif
#endif

#endif /* CPACKAGE_FIXTURES_EXPORT_H */
