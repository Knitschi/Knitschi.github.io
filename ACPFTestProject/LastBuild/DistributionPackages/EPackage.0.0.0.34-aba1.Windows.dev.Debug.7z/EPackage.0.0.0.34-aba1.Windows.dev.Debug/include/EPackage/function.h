#pragma once

#include <EPackage/epackage_export.h>

namespace e
{
	EPACKAGE_EXPORT void function();
}
