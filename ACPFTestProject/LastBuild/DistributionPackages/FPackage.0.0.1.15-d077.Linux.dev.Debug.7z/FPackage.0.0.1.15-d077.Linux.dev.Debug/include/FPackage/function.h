#pragma once

#include <FPackage/fpackage_export.h>

namespace f
{
	FPACKAGE_EXPORT void function();
}
