#pragma once

#include <CPackage/cpackage_fixtures_export.h>

namespace c
{
	class CPACKAGE_FIXTURES_EXPORT FunctionFixture
	{
	public:
		bool SetUp();
	};
}