#pragma once

#include <DPackage/dpackage_export.h>

namespace d
{
	DPACKAGE_EXPORT void function();
	DPACKAGE_EXPORT int function2();
}
