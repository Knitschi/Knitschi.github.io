var namespaces =
[
    [ "a", "namespacea.html", null ],
    [ "c", "namespacec.html", null ],
    [ "d", "namespaced.html", null ],
    [ "e", "namespacee.html", null ]
];