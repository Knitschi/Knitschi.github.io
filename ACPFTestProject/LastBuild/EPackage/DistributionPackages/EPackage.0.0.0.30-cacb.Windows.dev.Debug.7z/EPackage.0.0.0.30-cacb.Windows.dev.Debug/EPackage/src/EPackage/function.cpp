#include <EPackage/function.h>

namespace e
{
	void function() {}
}
