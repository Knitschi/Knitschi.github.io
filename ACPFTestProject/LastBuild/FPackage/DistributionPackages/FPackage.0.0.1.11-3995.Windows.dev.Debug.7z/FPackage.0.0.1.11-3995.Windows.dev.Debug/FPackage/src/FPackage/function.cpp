#include <FPackage/function.h>
#include <iostream>

namespace f
{
	void function()
	{
		std::cout << "FPackage function()"
				  << "\n";
		;
	}
}
