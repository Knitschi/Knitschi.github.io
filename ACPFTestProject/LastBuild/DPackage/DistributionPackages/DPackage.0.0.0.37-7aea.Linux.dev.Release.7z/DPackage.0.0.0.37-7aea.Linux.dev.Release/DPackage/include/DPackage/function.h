#pragma once

#include <DPackage/d_export.h>

namespace d
{
	D_EXPORT void function();
	D_EXPORT int function2();
}
