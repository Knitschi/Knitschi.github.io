#include <DPackage/function.h>
#include <iostream>

namespace d
{
	void function()
	{
		std::cout << "blub"
				  << "\n";
	}

	int function2()
	{
		return 5;
	}
}

namespace
{}