#pragma once

#include <EPackage/e_export.h>

namespace e
{
    E_EXPORT void function();
}
