#pragma once

#include <CPackage/c_tests_export.h>

namespace c
{
    class C_TESTS_EXPORT FunctionFixture
    {
    public:
        bool SetUp();
    };
}