#include <APackage/Tests/fixture.h>

namespace a
{
	void fixture() {}
}