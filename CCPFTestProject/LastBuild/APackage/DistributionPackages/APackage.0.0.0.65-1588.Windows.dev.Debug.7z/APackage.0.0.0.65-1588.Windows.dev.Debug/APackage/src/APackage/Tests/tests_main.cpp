#include <APackage/Tests/fixture.h>
#include <APackage/function.h>

int main()
{
	a::fixture();
	a::function();
	return 0;
}
