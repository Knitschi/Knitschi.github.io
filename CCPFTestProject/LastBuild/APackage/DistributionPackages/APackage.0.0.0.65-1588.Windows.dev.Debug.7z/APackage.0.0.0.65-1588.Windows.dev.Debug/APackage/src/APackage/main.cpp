
#include <APackage/Tests/generatedHeader.h>
#include <APackage/function.h>

int main()
{
	a::function();
	return MYNULL;
}
