#pragma once

#include <APackage/a_tests_export.h>

namespace a
{
	A_TESTS_EXPORT void fixture();
}