#pragma once

#include <APackage/a_export.h>

namespace a
{
	A_EXPORT void function();
}