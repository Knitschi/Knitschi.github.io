#pragma once

#define MYNULL 0
