#include <BPackage/Tests/fixture.h>

namespace b
{
	void fixture() {}
}