#include <BPackage/Tests/fixture.h>
#include <BPackage/function.h>

int main()
{
	b::fixture();
	b::function();
	return 0;
}
