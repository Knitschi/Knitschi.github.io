#include <BPackage/function.h>
#include <iostream>

namespace b
{
	void function() {}
}
