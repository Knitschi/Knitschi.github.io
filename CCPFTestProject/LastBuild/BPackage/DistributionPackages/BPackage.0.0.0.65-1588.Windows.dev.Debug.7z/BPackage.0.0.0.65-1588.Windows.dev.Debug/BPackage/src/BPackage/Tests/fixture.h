#pragma once

#include <BPackage/b_tests_export.h>

namespace b
{
	B_TESTS_EXPORT void fixture();
}