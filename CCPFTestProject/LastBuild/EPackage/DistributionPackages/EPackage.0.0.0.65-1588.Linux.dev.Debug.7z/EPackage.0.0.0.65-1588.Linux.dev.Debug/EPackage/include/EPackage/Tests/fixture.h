#include <EPackage/e_tests_export.h>


namespace e
{
	class E_TESTS_EXPORT MyFixture
	{
	  public:
		void setUp();
	};
}