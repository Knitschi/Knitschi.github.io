#pragma once

namespace e
{
	inline void function() {}
}
